import json
import mysql.connector
import boto3

def lambda_handler(event, context):
    vendor_id = event['vendor_id']
    decision = event['decision']  # 'APPROVE' or 'REJECT'
    reason = event.get('reason', '')
    user_role = event['user_role']
    execution_arn = event['execution_arn']
    
    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        port=3306,
        user='mdm_admin',
        password='Srinivas1998',
        database='nyc_taxi_mdm'
    )
    cursor = conn.cursor()
    
    if decision == 'APPROVE':
        # Approve
        cursor.execute("""
            UPDATE mdm_vendor 
            SET lifecycle_state = 'ACTIVE', 
                approved_by = %s, 
                approved_at = CURRENT_TIMESTAMP
            WHERE vendor_id = %s
        """, (user_role, vendor_id))
        
        cursor.execute("""
            INSERT INTO mdm_vendor_history (change_id, vendor_id, lifecycle_state, 
                                           approved_by, change_type, change_reason)
            SELECT change_id + 1, %s, 'ACTIVE', %s, 'UPDATE', %s FROM mdm_vendor WHERE vendor_id = %s
        """, (vendor_id, user_role, f"Steward approved: {reason}", vendor_id))
        
    else:
        # Reject - mark as DEPRECATED or keep PROPOSED with reason
        cursor.execute("""
            UPDATE mdm_vendor 
            SET lifecycle_state = 'DEPRECATED', updated_by = %s, updated_at = CURRENT_TIMESTAMP
            WHERE vendor_id = %s
        """, (user_role, vendor_id))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    # Signal Step Functions success
    sf_client = boto3.client('stepfunctions')
    sf_client.send_task_success(
        taskToken=event['task_token'],
        output=json.dumps({'decision': decision, 'vendor_id': vendor_id})
    )
    
    return {'statusCode': 200, 'decision': decision, 'vendor_id': vendor_id}
