import mysql.connector
import logging
import json
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def lambda_handler(event, context):
    """
    Log rejected records and move them to history tables
    
    Input:
    {
      "pipelineRunId": "mdm-run-2026-01-16T19:48:23.222Z-...",
    }
    
    Output:
    {
      "rejectedCount": 5,
      "rejectedByType": {
        "vendors": 2,
        "zones": 2,
        "ratecodes": 1
      }
    }
    """
    
    pipeline_run_id = event["pipelineRunId"]
    created_by = f'pipeline_{pipeline_run_id}'
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        rejected_counts = {
            "vendors": 0,
            "zones": 0,
            "ratecodes": 0
        }
        
        # Process rejected vendors
        cursor.execute("""
            SELECT vendor_id, source_vendor_id, vendor_name, match_confidence, 
                   source_system, created_at, created_by
            FROM mdm_vendor
            WHERE lifecycle_state = 'REJECTED' 
              AND created_by = %s
        """, (created_by,))
        
        rejected_vendors = cursor.fetchall()
        for vendor in rejected_vendors:
            # Insert into history
            cursor.execute("""
                INSERT INTO mdm_vendor_history 
                (vendor_id, vendor_name, lifecycle_state, match_confidence,
                 source_system, created_by, change_type, change_reason)
                VALUES (%s, %s, 'REJECTED', %s, %s, %s, 'STEWARD_REJECTION', 
                        'Rejected by data steward during review')
            """, (
                vendor['vendor_id'],
                vendor['vendor_name'],
                vendor['match_confidence'],
                vendor['source_system'],
                vendor['created_by']
            ))
            
            # Delete from main table
            cursor.execute("""
                DELETE FROM mdm_vendor WHERE vendor_id = %s
            """, (vendor['vendor_id'],))
            
            rejected_counts["vendors"] += 1
        
        # Process rejected zones
        cursor.execute("""
            SELECT zone_id, source_zone_id, zone_name, match_confidence,
                   source_system, created_at, created_by
            FROM mdm_zone
            WHERE lifecycle_state = 'REJECTED'
              AND created_by = %s
        """, (created_by,))
        
        rejected_zones = cursor.fetchall()
        for zone in rejected_zones:
            # Insert into history
            cursor.execute("""
                INSERT INTO mdm_zone_history
                (zone_id, zone_name, lifecycle_state, match_confidence,
                 source_system, created_by, change_type, change_reason)
                VALUES (%s, %s, 'REJECTED', %s, %s, %s, 'STEWARD_REJECTION',
                        'Rejected by data steward during review')
            """, (
                zone['zone_id'],
                zone['zone_name'],
                zone['match_confidence'],
                zone['source_system'],
                zone['created_by']
            ))
            
            # Delete from main table
            cursor.execute("""
                DELETE FROM mdm_zone WHERE zone_id = %s
            """, (zone['zone_id'],))
            
            rejected_counts["zones"] += 1
        
        # Process rejected ratecodes
        cursor.execute("""
            SELECT ratecode_id, source_ratecode_id, rate_code_desc, match_confidence,
                   source_system, created_at, created_by
            FROM mdm_ratecode
            WHERE lifecycle_state = 'REJECTED'
              AND created_by = %s
        """, (created_by,))
        
        rejected_ratecodes = cursor.fetchall()
        for ratecode in rejected_ratecodes:
            # Insert into history
            cursor.execute("""
                INSERT INTO mdm_ratecode_history
                (ratecode_id, rate_code_desc, lifecycle_state, match_confidence,
                 source_system, created_by, change_type, change_reason)
                VALUES (%s, %s, 'REJECTED', %s, %s, %s, 'STEWARD_REJECTION',
                        'Rejected by data steward during review')
            """, (
                ratecode['ratecode_id'],
                ratecode['rate_code_desc'],
                ratecode['match_confidence'],
                ratecode['source_system'],
                ratecode['created_by']
            ))
            
            # Delete from main table
            cursor.execute("""
                DELETE FROM mdm_ratecode WHERE ratecode_id = %s
            """, (ratecode['ratecode_id'],))
            
            rejected_counts["ratecodes"] += 1
        
        conn.commit()
        
        total_rejected = sum(rejected_counts.values())
        
        logger.info(
            f"Pipeline {pipeline_run_id}: Logged {total_rejected} rejected records - "
            f"Vendors: {rejected_counts['vendors']}, Zones: {rejected_counts['zones']}, "
            f"Ratecodes: {rejected_counts['ratecodes']}"
        )
        
        cursor.close()
        conn.close()
        
        return {
            "rejectedCount": total_rejected,
            "rejectedByType": rejected_counts
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error logging rejected records: {e}", exc_info=True)
        cursor.close()
        conn.close()
        raise
