import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def ensure_columns_and_indexes(cursor):
    """
    Ensure golden ID columns and indexes exist before updates
    Safe to run multiple times
    """

    required_columns = {
        "vendor_golden_id": "INT NULL",
        "pu_zone_golden_id": "INT NULL",
        "do_zone_golden_id": "INT NULL",
        "ratecode_golden_id": "INT NULL"
    }

    required_indexes = {
        "idx_vendor_golden": "vendor_golden_id",
        "idx_pu_zone_golden": "pu_zone_golden_id",
        "idx_do_zone_golden": "do_zone_golden_id",
        "idx_ratecode_golden": "ratecode_golden_id"
    }

    # Fetch existing columns
    cursor.execute("""
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = %s
          AND TABLE_NAME = 'mdm_golden_trip_level'
    """, (DB_CONFIG["database"],))
    existing_columns = {row[0] for row in cursor.fetchall()}

    # Add missing columns
    for col, ddl in required_columns.items():
        if col not in existing_columns:
            logger.info(f"Adding missing column: {col}")
            cursor.execute(
                f"ALTER TABLE mdm_golden_trip_level ADD COLUMN {col} {ddl}"
            )

    # Fetch existing indexes
    cursor.execute("""
        SELECT INDEX_NAME
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = %s
          AND TABLE_NAME = 'mdm_golden_trip_level'
    """, (DB_CONFIG["database"],))
    existing_indexes = {row[0] for row in cursor.fetchall()}

    # Add missing indexes
    for idx, col in required_indexes.items():
        if idx not in existing_indexes:
            logger.info(f"Adding missing index: {idx}")
            cursor.execute(
                f"CREATE INDEX {idx} ON mdm_golden_trip_level ({col})"
            )

def lambda_handler(event, context):
    """
    Create/update golden records table with enriched trip data
    """

    pipeline_run_id = event["pipelineRunId"]

    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)

    try:
        # ✅ Ensure schema is ready (NEW – safe & idempotent)
        ensure_columns_and_indexes(cursor)
        conn.commit()

        # Get all trips processed in this pipeline run
        cursor.execute("""
            SELECT DISTINCT trip_id
            FROM mdm_entity_match_temp
            WHERE pipeline_run_id = %s
        """, (pipeline_run_id,))

        trip_ids = [row['trip_id'] for row in cursor.fetchall()]

        if not trip_ids:
            logger.info(f"No trips to process for pipeline {pipeline_run_id}")
            return {
                "recordsCreated": 0,
                "recordsUpdated": 0
            }

        records_updated = 0

        for trip_id in trip_ids:
            cursor.execute("""
                SELECT 
                    entity_type,
                    source_id,
                    golden_id,
                    match_confidence,
                    lifecycle_state,
                    auto_approved
                FROM mdm_entity_match_temp
                WHERE pipeline_run_id = %s 
                  AND trip_id = %s
            """, (pipeline_run_id, trip_id))

            matches = cursor.fetchall()

            vendor_golden_id = None
            pu_zone_golden_id = None
            do_zone_golden_id = None
            ratecode_golden_id = None

            cursor.execute("""
                SELECT pulocationid, dolocationid
                FROM mdm_golden_trip_level
                WHERE trip_id = %s
            """, (trip_id,))
            trip = cursor.fetchone()

            if not trip:
                continue

            for match in matches:
                entity_type = match['entity_type']
                golden_id = match['golden_id']
                source_id = str(match['source_id'])

                if entity_type == 'vendor':
                    vendor_golden_id = golden_id
                elif entity_type == 'zone':
                    if str(trip['pulocationid']) == source_id:
                        pu_zone_golden_id = golden_id
                    elif str(trip['dolocationid']) == source_id:
                        do_zone_golden_id = golden_id
                elif entity_type == 'ratecode':
                    ratecode_golden_id = golden_id

            update_query = """
                UPDATE mdm_golden_trip_level
                SET data_zone = 'golden_trip_level'
            """
            params = []

            if vendor_golden_id is not None:
                update_query += ", vendor_golden_id = %s"
                params.append(vendor_golden_id)

            if pu_zone_golden_id is not None:
                update_query += ", pu_zone_golden_id = %s"
                params.append(pu_zone_golden_id)

            if do_zone_golden_id is not None:
                update_query += ", do_zone_golden_id = %s"
                params.append(do_zone_golden_id)

            if ratecode_golden_id is not None:
                update_query += ", ratecode_golden_id = %s"
                params.append(ratecode_golden_id)

            update_query += " WHERE trip_id = %s"
            params.append(trip_id)

            cursor.execute(update_query, params)
            records_updated += 1

        conn.commit()

        logger.info(
            f"Pipeline {pipeline_run_id}: Updated {records_updated} golden records"
        )

        cursor.close()
        conn.close()

        return {
            "recordsCreated": 0,
            "recordsUpdated": records_updated
        }

    except Exception as e:
        conn.rollback()
        logger.error(f"Error creating golden records: {e}", exc_info=True)
        cursor.close()
        conn.close()
        raise
