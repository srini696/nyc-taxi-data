import mysql.connector
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def levenshtein_distance(s1, s2):
    """Calculate Levenshtein distance between two strings"""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    
    if len(s2) == 0:
        return len(s1)
    
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]


def similarity_score(s1, s2):
    """Calculate similarity score (0-1) based on Levenshtein distance"""
    if not s1 or not s2:
        return 0.0
    
    s1_lower = s1.lower().strip()
    s2_lower = s2.lower().strip()
    
    distance = levenshtein_distance(s1_lower, s2_lower)
    max_len = max(len(s1_lower), len(s2_lower))
    
    if max_len == 0:
        return 1.0
    
    return 1.0 - (distance / max_len)


def lambda_handler(event, context):
    """
    Batch process trips without returning large datasets
    
    Input:
    {
      "pipelineRunId": "run_768990",
      "tripIds": [18001, 18002, ...],
      "sourceSystem": "nyc_taxi_curated"
    }
    
    Output:
    {
      "tripsProcessed": 100,
      "tripsNeedingReview": 5,
      "totalProcessed": 100
    }
    """
    
    pipeline_run_id = event["pipelineRunId"]
    trip_ids = event["tripIds"]
    source_system = event.get("sourceSystem", "nyc_taxi_curated")
    
    if not trip_ids:
        return {
            "tripsProcessed": 0,
            "tripsNeedingReview": 0,
            "totalProcessed": 0
        }
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Fetch trip metadata
        format_strings = ",".join(["%s"] * len(trip_ids))
        cursor.execute(f"""
            SELECT
                trip_id,
                vendorid,
                vendor_name,
                pulocationid,
                pu_zone,
                dolocationid,
                do_zone,
                ratecodeid,
                rate_code_desc
            FROM mdm_golden_trip_level
            WHERE trip_id IN ({format_strings})
        """, trip_ids)
        
        trips = cursor.fetchall()
        trip_map = {t["trip_id"]: t for t in trips}
        
        # Pre-fetch existing golden records
        cursor.execute("""
            SELECT source_vendor_id, vendor_id, vendor_name 
            FROM mdm_vendor 
            WHERE lifecycle_state='ACTIVE'
        """)
        active_vendors = {r["source_vendor_id"]: r for r in cursor.fetchall()}
        
        cursor.execute("""
            SELECT source_zone_id, zone_id, zone_name 
            FROM mdm_zone 
            WHERE lifecycle_state='ACTIVE'
        """)
        active_zones = {r["source_zone_id"]: r for r in cursor.fetchall()}
        
        cursor.execute("""
            SELECT source_ratecode_id, ratecode_id, rate_code_desc 
            FROM mdm_ratecode 
            WHERE lifecycle_state='ACTIVE'
        """)
        active_ratecodes = {r["source_ratecode_id"]: r for r in cursor.fetchall()}
        
        # Process each trip
        trips_needing_review = 0
        trips_processed = 0
        
        for trip_id, trip in trip_map.items():
            needs_review = False
            
            # Process vendor
            vid = trip["vendorid"]
            if vid:
                if vid not in active_vendors:
                    match_result = fuzzy_match_entity(
                        cursor, 'vendor', trip["vendor_name"], 
                        list(active_vendors.values())
                    )
                    needs_review = process_entity_match(
                        cursor, pipeline_run_id, trip_id, 'vendor',
                        vid, trip["vendor_name"], match_result, source_system
                    ) or needs_review
            
            # Process pickup zone
            pu = trip["pulocationid"]
            if pu:
                if pu not in active_zones:
                    match_result = fuzzy_match_entity(
                        cursor, 'zone', trip["pu_zone"], 
                        list(active_zones.values())
                    )
                    needs_review = process_entity_match(
                        cursor, pipeline_run_id, trip_id, 'zone',
                        pu, trip["pu_zone"], match_result, source_system
                    ) or needs_review
            
            # Process dropoff zone
            do = trip["dolocationid"]
            if do:
                if do not in active_zones:
                    match_result = fuzzy_match_entity(
                        cursor, 'zone', trip["do_zone"], 
                        list(active_zones.values())
                    )
                    needs_review = process_entity_match(
                        cursor, pipeline_run_id, trip_id, 'zone',
                        do, trip["do_zone"], match_result, source_system
                    ) or needs_review
            
            # Process ratecode
            rc = trip["ratecodeid"]
            if rc:
                if rc not in active_ratecodes:
                    match_result = fuzzy_match_entity(
                        cursor, 'ratecode', trip["rate_code_desc"], 
                        list(active_ratecodes.values())
                    )
                    needs_review = process_entity_match(
                        cursor, pipeline_run_id, trip_id, 'ratecode',
                        rc, trip["rate_code_desc"], match_result, source_system
                    ) or needs_review
            
            if needs_review:
                trips_needing_review += 1
            
            trips_processed += 1
        
        conn.commit()
        
        logger.info(
            f"Pipeline {pipeline_run_id}: Processed {trips_processed} trips, "
            f"{trips_needing_review} need review"
        )
        
        return {
            "tripsProcessed": trips_processed,
            "tripsNeedingReview": trips_needing_review,
            "totalProcessed": trips_processed
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error processing batch: {e}", exc_info=True)
        raise
    finally:
        cursor.close()
        conn.close()


def fuzzy_match_entity(cursor, entity_type, proposed_name, active_entities):
    """
    Perform fuzzy matching using Levenshtein distance
    Returns: (matched_entity, confidence) or (None, 0.0)
    """
    if not proposed_name or not active_entities:
        return None, 0.0
    
    # Map entity type to name field
    name_field_map = {
        'vendor': 'vendor_name',
        'zone': 'zone_name',
        'ratecode': 'rate_code_desc'
    }
    
    name_field = name_field_map.get(entity_type)
    if not name_field:
        return None, 0.0
    
    best_match = None
    best_score = 0.0
    
    # Calculate similarity with all active entities
    for entity in active_entities:
        entity_name = entity.get(name_field, '')
        if not entity_name:
            continue
        
        score = similarity_score(proposed_name, entity_name)
        
        if score > best_score:
            best_score = score
            best_match = entity
    
    # Return match only if confidence is above threshold (85%)
    if best_score >= 0.85:
        return best_match, best_score
    
    return None, 0.0


def process_entity_match(cursor, pipeline_run_id, trip_id, entity_type, 
                         source_id, proposed_name, match_result, source_system):
    """
    Process entity matching result and insert into mdm_entity_match_temp
    Returns: True if needs review, False if auto-approved
    """
    matched_entity, confidence = match_result
    
    if matched_entity and confidence >= 0.85:
        # High confidence match - auto-approve
        golden_id = get_golden_id(matched_entity, entity_type)
        lifecycle_state = 'MATCHED'
        auto_approved = True
        needs_review = False
        
        logger.info(
            f"Auto-matched {entity_type} {source_id} to golden_id {golden_id} "
            f"with confidence {confidence:.4f}"
        )
    else:
        # Low confidence or no match - needs steward review
        golden_id = None
        lifecycle_state = 'NEW'
        auto_approved = False
        needs_review = True
        confidence = confidence if confidence > 0 else None
        
        # Create proposed master record
        create_proposed_master(
            cursor, entity_type, source_id, proposed_name, 
            source_system, pipeline_run_id
        )
        
        logger.info(
            f"No match found for {entity_type} {source_id}, created PROPOSED record"
        )
    
    # Insert into match temp table
    cursor.execute("""
        INSERT INTO mdm_entity_match_temp 
        (pipeline_run_id, trip_id, entity_type, source_id, proposed_name, 
         golden_id, match_confidence, lifecycle_state, auto_approved)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            golden_id = VALUES(golden_id),
            match_confidence = VALUES(match_confidence),
            lifecycle_state = VALUES(lifecycle_state),
            auto_approved = VALUES(auto_approved),
            updated_at = CURRENT_TIMESTAMP
    """, (
        pipeline_run_id, trip_id, entity_type, str(source_id), 
        proposed_name, golden_id, confidence, lifecycle_state, auto_approved
    ))
    
    return needs_review


def get_golden_id(entity, entity_type):
    """Extract golden ID from entity based on type"""
    id_map = {
        'vendor': 'vendor_id',
        'zone': 'zone_id',
        'ratecode': 'ratecode_id'
    }
    return entity.get(id_map.get(entity_type))


def create_proposed_master(cursor, entity_type, source_id, proposed_name, 
                           source_system, pipeline_run_id):
    """Create a PROPOSED master record that requires steward approval"""
    
    table_map = {
        'vendor': ('mdm_vendor', 'source_vendor_id', 'vendor_name'),
        'zone': ('mdm_zone', 'source_zone_id', 'zone_name'),
        'ratecode': ('mdm_ratecode', 'source_ratecode_id', 'rate_code_desc')
    }
    
    if entity_type not in table_map:
        return
    
    table_name, source_id_col, name_col = table_map[entity_type]
    
    # Check if already exists
    cursor.execute(f"""
        SELECT {source_id_col} FROM {table_name} 
        WHERE {source_id_col} = %s
    """, (source_id,))
    
    if cursor.fetchone():
        logger.info(f"{entity_type} {source_id} already exists")
        return
    
    # Insert PROPOSED record
    cursor.execute(f"""
        INSERT INTO {table_name} 
        ({source_id_col}, {name_col}, lifecycle_state, match_confidence, 
         source_system, created_by)
        VALUES (%s, %s, 'PROPOSED', NULL, %s, %s)
    """, (
        source_id, 
        proposed_name or f'{entity_type.capitalize()}_{source_id}',
        source_system,
        f'pipeline_{pipeline_run_id}'
    ))
    
    logger.info(f"Created PROPOSED {entity_type}: {source_id} - {proposed_name}")