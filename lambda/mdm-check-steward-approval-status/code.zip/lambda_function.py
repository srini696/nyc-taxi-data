"""
Lambda: mdm-check-steward-approval-status
Purpose: Check if stewards have approved PROPOSED records
Use Case: Optional polling loop to wait for approvals
"""

import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def lambda_handler(event, context):
    """
    Check approval status of PROPOSED records
    
    Input:
    {
      "pipelineRunId": "mdm-run-2026-01-16..."
    }
    
    Output:
    {
      "allApproved": true/false,
      "stillPending": true/false,
      "anyRejected": true/false,
      "counts": {
        "proposed": 0,
        "active": 5,
        "rejected": 0
      }
    }
    """
    
    pipeline_run_id = event["pipelineRunId"]
    created_by = f'pipeline_{pipeline_run_id}'
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Count records by lifecycle_state across all entity types
        counts = {
            "proposed": 0,
            "active": 0,
            "rejected": 0
        }
        
        # Check vendors
        cursor.execute("""
            SELECT lifecycle_state, COUNT(*) as cnt
            FROM mdm_vendor
            WHERE created_by = %s
            GROUP BY lifecycle_state
        """, (created_by,))
        
        for row in cursor.fetchall():
            state = row['lifecycle_state'].lower()
            if state == 'proposed':
                counts['proposed'] += row['cnt']
            elif state == 'active':
                counts['active'] += row['cnt']
            elif state == 'rejected':
                counts['rejected'] += row['cnt']
        
        # Check zones
        cursor.execute("""
            SELECT lifecycle_state, COUNT(*) as cnt
            FROM mdm_zone
            WHERE created_by = %s
            GROUP BY lifecycle_state
        """, (created_by,))
        
        for row in cursor.fetchall():
            state = row['lifecycle_state'].lower()
            if state == 'proposed':
                counts['proposed'] += row['cnt']
            elif state == 'active':
                counts['active'] += row['cnt']
            elif state == 'rejected':
                counts['rejected'] += row['cnt']
        
        # Check ratecodes
        cursor.execute("""
            SELECT lifecycle_state, COUNT(*) as cnt
            FROM mdm_ratecode
            WHERE created_by = %s
            GROUP BY lifecycle_state
        """, (created_by,))
        
        for row in cursor.fetchall():
            state = row['lifecycle_state'].lower()
            if state == 'proposed':
                counts['proposed'] += row['cnt']
            elif state == 'active':
                counts['active'] += row['cnt']
            elif state == 'rejected':
                counts['rejected'] += row['cnt']
        
        # Determine status
        all_approved = counts['proposed'] == 0 and counts['active'] > 0 and counts['rejected'] == 0
        still_pending = counts['proposed'] > 0
        any_rejected = counts['rejected'] > 0
        
        logger.info(
            f"Pipeline {pipeline_run_id} approval status - "
            f"Proposed: {counts['proposed']}, Active: {counts['active']}, "
            f"Rejected: {counts['rejected']}"
        )
        
        cursor.close()
        conn.close()
        
        return {
            "allApproved": all_approved,
            "stillPending": still_pending,
            "anyRejected": any_rejected,
            "counts": counts,
            "pipelineRunId": pipeline_run_id
        }
        
    except Exception as e:
        logger.error(f"Error checking approval status: {e}", exc_info=True)
        cursor.close()
        conn.close()
        raise
