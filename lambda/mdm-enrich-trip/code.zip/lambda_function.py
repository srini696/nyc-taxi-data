"""
MDM Enrich Approved Trips Lambda
Enriches trips that were waiting for the newly approved master data
Only processes trips marked as needs_approval=TRUE and is_enriched=FALSE
"""

import mysql.connector
from mysql.connector import pooling
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998",
    "autocommit": False
}

connection_pool = None


def get_connection_pool():
    """Get or create database connection pool"""
    global connection_pool
    if connection_pool is None:
        connection_pool = pooling.MySQLConnectionPool(
            pool_name="mdm_enrich_pool",
            pool_size=5,
            pool_reset_session=True,
            **DB_CONFIG
        )
    return connection_pool


def lambda_handler(event, context):
    """
    Enrich trips with newly approved master data
    Only processes trips that needed approval and haven't been enriched yet
    OPTIMIZED: Uses single multi-value UPDATE for each entity type
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    approved_records = event.get('approvedRecords', [])
    
    if not approved_records:
        logger.info("No approved records to process")
        return {
            "tripsEnriched": 0,
            "stats": {
                "vendors": 0,
                "zones": 0,
                "ratecodes": 0
            }
        }
    
    logger.info(f"Enriching trips with {len(approved_records)} newly approved records")
    
    pool = get_connection_pool()
    conn = pool.get_connection()
    cursor = conn.cursor(dictionary=True)
    
    stats = {
        "vendors": 0,
        "zones": 0,
        "ratecodes": 0
    }
    
    trips_enriched = 0
    
    try:
        # Organize approved records by type
        approved_vendors = {}
        approved_zones = {}
        approved_ratecodes = {}
        
        for record in approved_records:
            entity_type = record['entity_type']
            source_id = record['source_id']
            golden_id = record['golden_id']
            
            if entity_type == 'VENDOR':
                approved_vendors[source_id] = golden_id
            elif entity_type == 'ZONE':
                approved_zones[source_id] = golden_id
            elif entity_type == 'RATECODE':
                approved_ratecodes[source_id] = golden_id
        
        logger.info(
            f"Approved: {len(approved_vendors)} vendors, "
            f"{len(approved_zones)} zones, {len(approved_ratecodes)} ratecodes"
        )
        
        # ================================================================
        # OPTIMIZED: Single UPDATE with CASE statement for vendors
        # ================================================================
        if approved_vendors:
            source_ids = list(approved_vendors.keys())
            when_clauses = ' '.join([
                f"WHEN {source_id} THEN {golden_id}"
                for source_id, golden_id in approved_vendors.items()
            ])
            placeholders = ','.join(['%s'] * len(source_ids))
            
            query = f"""
                UPDATE mdm_golden_trip_level t
                INNER JOIN mdm_process_tracker pt ON t.trip_id = pt.trip_id
                SET t.vendor_golden_id = CASE t.vendorid {when_clauses} END
                WHERE t.vendorid IN ({placeholders})
                  AND pt.needs_approval = TRUE
                  AND pt.is_enriched = FALSE
                  AND t.vendor_golden_id IS NULL
            """
            
            cursor.execute(query, source_ids)
            stats["vendors"] = cursor.rowcount
            logger.info(f"Enriched {stats['vendors']} trips with {len(approved_vendors)} vendors")
        
        # ================================================================
        # OPTIMIZED: Single UPDATE with CASE for pickup zones
        # ================================================================
        if approved_zones:
            source_ids = list(approved_zones.keys())
            when_clauses = ' '.join([
                f"WHEN {source_id} THEN {golden_id}"
                for source_id, golden_id in approved_zones.items()
            ])
            placeholders = ','.join(['%s'] * len(source_ids))
            
            # Update pickup zones
            query = f"""
                UPDATE mdm_golden_trip_level t
                INNER JOIN mdm_process_tracker pt ON t.trip_id = pt.trip_id
                SET t.pu_zone_golden_id = CASE t.pulocationid {when_clauses} END
                WHERE t.pulocationid IN ({placeholders})
                  AND pt.needs_approval = TRUE
                  AND pt.is_enriched = FALSE
                  AND t.pu_zone_golden_id IS NULL
            """
            
            cursor.execute(query, source_ids)
            pu_updated = cursor.rowcount
            logger.info(f"Enriched {pu_updated} trips with pickup zones")
            
            # Update dropoff zones
            query = f"""
                UPDATE mdm_golden_trip_level t
                INNER JOIN mdm_process_tracker pt ON t.trip_id = pt.trip_id
                SET t.do_zone_golden_id = CASE t.dolocationid {when_clauses} END
                WHERE t.dolocationid IN ({placeholders})
                  AND pt.needs_approval = TRUE
                  AND pt.is_enriched = FALSE
                  AND t.do_zone_golden_id IS NULL
            """
            
            cursor.execute(query, source_ids)
            do_updated = cursor.rowcount
            logger.info(f"Enriched {do_updated} trips with dropoff zones")
            
            stats["zones"] = pu_updated + do_updated
        
        # ================================================================
        # OPTIMIZED: Single UPDATE with CASE for ratecodes
        # ================================================================
        if approved_ratecodes:
            source_ids = list(approved_ratecodes.keys())
            when_clauses = ' '.join([
                f"WHEN {source_id} THEN {golden_id}"
                for source_id, golden_id in approved_ratecodes.items()
            ])
            placeholders = ','.join(['%s'] * len(source_ids))
            
            query = f"""
                UPDATE mdm_golden_trip_level t
                INNER JOIN mdm_process_tracker pt ON t.trip_id = pt.trip_id
                SET t.ratecode_golden_id = CASE t.ratecodeid {when_clauses} END
                WHERE t.ratecodeid IN ({placeholders})
                  AND pt.needs_approval = TRUE
                  AND pt.is_enriched = FALSE
                  AND t.ratecode_golden_id IS NULL
            """
            
            cursor.execute(query, source_ids)
            stats["ratecodes"] = cursor.rowcount
            logger.info(f"Enriched {stats['ratecodes']} trips with {len(approved_ratecodes)} ratecodes")
        
        # ================================================================
        # MARK ENRICHED TRIPS IN TRACKER (OPTIMIZED)
        # ================================================================
        # Mark trips as enriched if they now have all required golden IDs
        # This query is much faster as it only updates relevant trips
        cursor.execute("""
            UPDATE mdm_process_tracker pt
            INNER JOIN mdm_golden_trip_level t ON pt.trip_id = t.trip_id
            SET pt.is_enriched = TRUE,
                pt.match_status = 'COMPLETED'
            WHERE pt.needs_approval = TRUE
              AND pt.is_enriched = FALSE
              AND pt.pipeline_run_id = %s
              AND (t.vendorid IS NULL OR t.vendor_golden_id IS NOT NULL)
              AND (t.pulocationid IS NULL OR t.pu_zone_golden_id IS NOT NULL)
              AND (t.dolocationid IS NULL OR t.do_zone_golden_id IS NOT NULL)
              AND (t.ratecodeid IS NULL OR t.ratecode_golden_id IS NOT NULL)
        """, (pipeline_run_id,))
        
        trips_enriched = cursor.rowcount
        logger.info(f"Marked {trips_enriched} trips as enriched and completed")
        
        conn.commit()
        
        total_updates = stats["vendors"] + stats["zones"] + stats["ratecodes"]
        
        logger.info(
            f"Enrichment complete: {trips_enriched} trips fully enriched, "
            f"{total_updates} total golden ID updates"
        )
        
        return {
            "tripsEnriched": trips_enriched,
            "stats": stats,
            "totalUpdates": total_updates
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Enrichment failed: {e}", exc_info=True)
        return {
            "tripsEnriched": 0,
            "stats": stats,
            "error": str(e)
        }
        
    finally:
        cursor.close()
        conn.close()