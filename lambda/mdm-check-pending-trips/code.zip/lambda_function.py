"""
Check if there are trips in PENDING_APPROVAL status waiting for steward action
"""

import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}


def lambda_handler(event, context):
    """
    Check if there are trips waiting for steward approval
    Returns True if there are PENDING_APPROVAL trips that haven't been enriched
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Count trips pending approval
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM mdm_process_tracker
            WHERE match_status = 'PENDING_APPROVAL'
              AND needs_approval = TRUE
              AND is_enriched = FALSE
        """)
        pending_count = cursor.fetchone()['count']
        
        # Also check if there are PROPOSED records
        cursor.execute("""
            SELECT 
                (SELECT COUNT(*) FROM mdm_vendor WHERE lifecycle_state = 'PROPOSED') as vendors,
                (SELECT COUNT(*) FROM mdm_zone WHERE lifecycle_state = 'PROPOSED') as zones,
                (SELECT COUNT(*) FROM mdm_ratecode WHERE lifecycle_state = 'PROPOSED') as ratecodes
        """)
        proposed = cursor.fetchone()
        
        total_proposed = proposed['vendors'] + proposed['zones'] + proposed['ratecodes']
        
        logger.info(
            f"Pipeline {pipeline_run_id} - Pending trips: {pending_count}, "
            f"PROPOSED records: {total_proposed} (V:{proposed['vendors']}, "
            f"Z:{proposed['zones']}, R:{proposed['ratecodes']})"
        )
        
        return {
            "hasPendingTrips": pending_count > 0,
            "pendingTripsCount": pending_count,
            "proposedRecords": {
                "vendors": proposed['vendors'],
                "zones": proposed['zones'],
                "ratecodes": proposed['ratecodes'],
                "total": total_proposed
            }
        }
        
    finally:
        cursor.close()
        conn.close()
