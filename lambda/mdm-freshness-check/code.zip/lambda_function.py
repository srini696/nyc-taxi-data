import mysql.connector
from datetime import datetime, timedelta
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """Check if MDM tables updated within 7 days"""
    
    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        database='nyc_taxi_mdm',
        user='mdm_admin',
        password='Srinivas1998'
    )
    cursor = conn.cursor()
    
    tables = ['mdm_vendor', 'mdm_zone', 'mdm_ratecode']
    freshness = {}
    stale_threshold = datetime.now() - timedelta(days=7)
    
    for table in tables:
        cursor.execute(f"SELECT MAX(updated_at) FROM {table} WHERE lifecycle_state='ACTIVE'")
        last_update = cursor.fetchone()[0]
        freshness[table] = last_update > stale_threshold if last_update else False
    
    cursor.close()
    conn.close()
    
    is_fresh = all(freshness.values())
    return {
        'isFresh': is_fresh,
        'staleTables': [k for k,v in freshness.items() if not v],
        'freshnessScore': sum(freshness.values()) / len(freshness) * 100
    }
