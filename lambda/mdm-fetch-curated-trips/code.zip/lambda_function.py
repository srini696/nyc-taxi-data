"""
Lambda Function: mdm-fetch-curated-trips
Purpose: Fetch unprocessed trips from curated zone for MDM processing
"""

import mysql.connector
from mysql.connector import pooling
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Global connection pool (reused across invocations)
connection_pool = None

def get_connection_pool():
    """Create or return existing connection pool"""
    global connection_pool
    
    if connection_pool is None:
        logger.info("Creating new MySQL connection pool")
        connection_pool = pooling.MySQLConnectionPool(
            pool_name="mdm_pool",
            pool_size=5,
            pool_reset_session=True,
            host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
            database='nyc_taxi_mdm',
            user='mdm_admin',
            password='Srinivas1998',
            connect_timeout=10,
            autocommit=True
        )
    
    return connection_pool

# ============================================================================
# OPTIMIZATION 2: Faster mdm-fetch-curated-trips
# ============================================================================

def lambda_handler(event, context):
    """
    Optimized: Fetch trips with connection pooling and pagination
    """
    import json
    from datetime import datetime
    
    pipeline_run_id = event.get('pipelineRunId', 'unknown')
    batch_size = event.get('batchSize', 1000)
    processing_mode = event.get('processingMode', 'incremental')
    
    # Calculate remaining time to avoid timeout
    remaining_time = context.get_remaining_time_in_millis()
    logger.info(f"Starting fetch with {remaining_time}ms remaining")
    
    if remaining_time < 10000:  # Less than 10 seconds
        logger.warning("Not enough time remaining, aborting")
        return {
            'trips': [],
            'recordCount': 0,
            'hasMore': False,
            'error': 'Insufficient time remaining'
        }
    
    try:
        # Get connection from pool
        pool = get_connection_pool()
        conn = pool.get_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Optimized query with LIMIT and indexes
        query = """
            SELECT 
                t.trip_id, t.vendorid, t.tpep_pickup_datetime, t.tpep_dropoff_datetime,
                t.passenger_count, t.trip_distance, t.ratecodeid,
                t.pulocationid, t.dolocationid, t.payment_type,
                t.fare_amount, t.tip_amount, t.total_amount,
                t.vendor_name, t.rate_code_desc,
                t.pu_zone, t.pu_borough, t.do_zone, t.do_borough
            FROM mdm_golden_trip_level t
            WHERE t.data_zone = 'curated_trip_level'
              AND NOT EXISTS (
                  SELECT 1 FROM mdm_trip_processing_tracker p 
                  WHERE p.trip_id = t.trip_id 
                    AND p.processing_status = 'COMPLETED'
              )
            ORDER BY t.trip_id
            LIMIT %s
        """
        
        cursor.execute(query, (batch_size,))
      
        trips = cursor.fetchall()
        '''
        # Convert datetime objects to strings
        for trip in trips:
            for key, value in trip.items():
                if isinstance(value, datetime):
                    trip[key] = value.strftime('%Y-%m-%d %H:%M:%S')
        '''
        logger.info(f"Fetched {len(trips)} trips")
        if trips:
            trip_ids = [trip['trip_id'] for trip in trips]
            placeholders = ','.join(['%s'] * len(trip_ids))
            
            cursor.execute(f"""
                INSERT INTO mdm_trip_processing_tracker (trip_id, pipeline_run_id, processing_status)
                VALUES {','.join(['(%s, %s, %s)'] * len(trip_ids))}
                ON DUPLICATE KEY UPDATE 
                    pipeline_run_id = VALUES(pipeline_run_id),
                    processing_status = 'COMPLETED'
            """, [item for trip_id in trip_ids for item in (trip_id, pipeline_run_id, 'COMPLETED')])
            
            conn.commit()
        
        # Format for state machine
        #trip_ids = [row[0] for row in cursor.fetchall()]

        cursor.close()
        conn.close()

        return {
            "pipelineRunId": pipeline_run_id,
            "tripIds": trip_ids,
            "recordCount": len(trip_ids),
            "hasMore": len(trip_ids) == batch_size
        }
        
    except Exception as e:
        logger.error(f"Error fetching trips: {e}", exc_info=True)
        return {
            'trips': [],
            'recordCount': 0,
            'hasMore': False,
            'error': str(e)
        }

