import mysql.connector
import logging
import json
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def lambda_handler(event, context):
    """
    Log pipeline execution details to audit table
    
    Input for SUCCESS:
    {
      "pipelineRunId": "mdm-run-2026-01-16T19:48:23.222Z-...",
      "executionStatus": "SUCCESS",
      "glueJobs": {
        "rawToValidated": {...},
        "validatedToCurated": {...}
      },
      "recordsProcessed": 100,
      "goldenRecordsCreated": 95,
      "pendingReviews": 0,
      "executionTime": {
        "start": "2026-01-16T19:48:23.222Z",
        "end": "2026-01-16T19:55:30.123Z"
      }
    }
    
    Input for FAILURE:
    {
      "pipelineRunId": "mdm-run-2026-01-16T19:48:23.222Z-...",
      "executionStatus": "GLUE_FAILURE",
      "error": {...}
    }
    
    Output:
    {
      "auditId": 12345,
      "status": "LOGGED"
    }
    """
    
    pipeline_run_id = event.get("pipelineRunId", "unknown")
    execution_status = event.get("executionStatus", "UNKNOWN")
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Parse execution times
        execution_time = event.get("executionTime", {})
        start_time = execution_time.get("start")
        end_time = execution_time.get("end")
        
        # Convert ISO format to datetime if needed
        if start_time and isinstance(start_time, str):
            try:
                start_time = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
            except:
                start_time = datetime.now()
        
        if end_time and isinstance(end_time, str):
            try:
                end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
            except:
                end_time = datetime.now()
        
        # Calculate quality score based on auto-approval rate
        records_processed = event.get("recordsProcessed", 0)
        pending_reviews = event.get("pendingReviews", 0)
        
        if records_processed > 0:
            auto_approved = records_processed - pending_reviews
            quality_score = (auto_approved / records_processed) * 100
        else:
            quality_score = 0.0
        
        # Get Glue job info
        glue_jobs = event.get("glueJobs", {})
        raw_to_validated = glue_jobs.get("rawToValidated", {})
        validated_to_curated = glue_jobs.get("validatedToCurated", {})
        
        # Prepare step function execution ARN
        stepfn_execution = context.invoked_function_arn if context else None
        
        # Insert audit record for each entity type
        entity_types = ["vendor", "zone", "ratecode"]
        audit_ids = []
        
        for entity_type in entity_types:
            cursor.execute("""
                INSERT INTO mdm_pipeline_audit
                (pipeline_run_id, triggered_by, entity_type, records_processed,
                 records_approved, quality_score, status, stepfn_execution,
                 run_start, run_end)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                pipeline_run_id,
                'step_functions',
                entity_type,
                records_processed,
                records_processed - pending_reviews,
                quality_score,
                execution_status,
                stepfn_execution,
                start_time or datetime.now(),
                end_time or datetime.now()
            ))
            
            audit_ids.append(cursor.lastrowid)
        
        conn.commit()
        
        logger.info(
            f"Pipeline {pipeline_run_id}: Logged execution with status {execution_status}. "
            f"Processed: {records_processed}, Quality Score: {quality_score:.2f}%"
        )
        
        cursor.close()
        conn.close()
        
        return {
            "auditId": audit_ids[0] if audit_ids else None,
            "status": "LOGGED",
            "pipelineRunId": pipeline_run_id,
            "executionStatus": execution_status
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error logging pipeline execution: {e}", exc_info=True)
        cursor.close()
        conn.close()
        
        # Don't fail the pipeline just because logging failed
        return {
            "auditId": None,
            "status": "LOGGING_FAILED",
            "error": str(e)
        }
