"""
MDM Update Audit Lambda
Updates mdm_pipeline_audit table with pipeline execution statistics
"""

import mysql.connector
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}


def lambda_handler(event, context):
    """
    Update or insert audit record for pipeline execution
    
    Event types:
    - 'start': Create initial audit record
    - 'batch_update': Update with batch processing stats
    - 'approval_update': Update with approval stats
    - 'complete': Final update with completion status
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    event_type = event.get('eventType', 'update')
    
    logger.info(f"Updating audit for pipeline {pipeline_run_id}, event type: {event_type}")
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        if event_type == 'start':
            # Create initial audit record
            cursor.execute("""
                INSERT INTO mdm_pipeline_audit (
                    pipeline_run_id,
                    triggered_by,
                    entity_type,
                    records_processed,
                    records_approved,
                    quality_score,
                    status,
                    stepfn_execution,
                    run_start
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                pipeline_run_id,
                event.get('triggeredBy', 'step-functions'),
                'TRIP',
                0,
                0,
                0.00,
                'RUNNING',
                event.get('executionArn', ''),
                datetime.now()
            ))
            
            logger.info(f"Created initial audit record for {pipeline_run_id}")
            
        elif event_type == 'batch_update':
            # Update with batch processing statistics
            total_processed = event.get('totalProcessed', 0)
            total_auto_approved = event.get('totalAutoApproved', 0)
            total_needing_review = event.get('totalNeedingReview', 0)
            
            # Calculate quality score (auto-approval rate)
            total_matches = total_auto_approved + total_needing_review
            quality_score = (total_auto_approved / total_matches * 100) if total_matches > 0 else 100.0
            
            cursor.execute("""
                UPDATE mdm_pipeline_audit
                SET records_processed = %s,
                    records_approved = %s,
                    quality_score = %s,
                    status = %s
                WHERE pipeline_run_id = %s
            """, (
                total_processed,
                total_auto_approved,
                quality_score,
                'WAITING_APPROVAL' if total_needing_review > 0 else 'RUNNING',
                pipeline_run_id
            ))
            
            logger.info(
                f"Updated audit: processed={total_processed}, "
                f"approved={total_auto_approved}, quality={quality_score:.2f}%"
            )
            
        elif event_type == 'approval_update':
            # Update with approval statistics
            approval_stats = event.get('approvalStats', {})
            
            cursor.execute("""
                UPDATE mdm_pipeline_audit
                SET records_approved = records_approved + %s,
                    status = %s
                WHERE pipeline_run_id = %s
            """, (
                approval_stats.get('totalApproved', 0),
                'ENRICHING',
                pipeline_run_id
            ))
            
            logger.info(f"Updated audit with {approval_stats.get('totalApproved', 0)} new approvals")
            
        elif event_type == 'complete':
            # Final update with completion status
            final_stats = event.get('finalStats', {})
            
            cursor.execute("""
                UPDATE mdm_pipeline_audit
                SET status = %s,
                    run_end = %s
                WHERE pipeline_run_id = %s
            """, (
                'COMPLETED',
                datetime.now(),
                pipeline_run_id
            ))
            
            logger.info(f"Marked pipeline {pipeline_run_id} as COMPLETED")
            
        elif event_type == 'failed':
            # Update with failure status
            error_info = event.get('error', 'Unknown error')
            
            cursor.execute("""
                UPDATE mdm_pipeline_audit
                SET status = %s,
                    run_end = %s
                WHERE pipeline_run_id = %s
            """, (
                'FAILED',
                datetime.now(),
                pipeline_run_id
            ))
            
            logger.error(f"Marked pipeline {pipeline_run_id} as FAILED: {error_info}")
        
        conn.commit()
        
        # Return current audit record
        cursor.execute("""
            SELECT * FROM mdm_pipeline_audit
            WHERE pipeline_run_id = %s
        """, (pipeline_run_id,))
        
        audit_record = cursor.fetchone()
        
        # Convert datetime objects to strings for JSON serialization
        if audit_record:
            if audit_record.get('run_start'):
                audit_record['run_start'] = audit_record['run_start'].isoformat()
            if audit_record.get('run_end'):
                audit_record['run_end'] = audit_record['run_end'].isoformat()
            if audit_record.get('created_at'):
                audit_record['created_at'] = audit_record['created_at'].isoformat()
        
        return {
            "status": "success",
            "pipelineRunId": pipeline_run_id,
            "eventType": event_type,
            "auditRecord": audit_record
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error updating audit: {e}", exc_info=True)
        return {
            "status": "error",
            "pipelineRunId": pipeline_run_id,
            "eventType": event_type,
            "error": str(e)
        }
        
    finally:
        cursor.close()
        conn.close()