"""
Lambda: mdm-auto-approve-proposed
Purpose: Automatically approve all PROPOSED records for a pipeline run
Use Case: When steward wants to bulk approve via API/automation
"""

import mysql.connector
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def lambda_handler(event, context):
    """
    Auto-approve all PROPOSED records for a pipeline run
    
    Input:
    {
      "pipelineRunId": "mdm-run-2026-01-16...",
      "approvedBy": "steward_name" (optional)
    }
    
    Output:
    {
      "approved": {
        "vendors": 2,
        "zones": 2,
        "ratecodes": 1
      },
      "total": 5
    }
    """
    
    pipeline_run_id = event["pipelineRunId"]
    approved_by = event.get("approvedBy", "auto_approval_system")
    created_by = f'pipeline_{pipeline_run_id}'
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        approved_counts = {
            "vendors": 0,
            "zones": 0,
            "ratecodes": 0
        }
        
        # Approve vendors
        cursor.execute("""
            UPDATE mdm_vendor 
            SET 
                lifecycle_state = 'ACTIVE',
                approved_at = NOW(),
                approved_by = %s,
                updated_at = NOW(),
                updated_by = %s
            WHERE created_by = %s
              AND lifecycle_state = 'PROPOSED'
        """, (approved_by, approved_by, created_by))
        
        approved_counts["vendors"] = cursor.rowcount
        
        # Approve zones
        cursor.execute("""
            UPDATE mdm_zone 
            SET 
                lifecycle_state = 'ACTIVE',
                approved_at = NOW(),
                approved_by = %s,
                updated_at = NOW(),
                updated_by = %s
            WHERE created_by = %s
              AND lifecycle_state = 'PROPOSED'
        """, (approved_by, approved_by, created_by))
        
        approved_counts["zones"] = cursor.rowcount
        
        # Approve ratecodes
        cursor.execute("""
            UPDATE mdm_ratecode 
            SET 
                lifecycle_state = 'ACTIVE',
                approved_at = NOW(),
                approved_by = %s,
                updated_at = NOW(),
                updated_by = %s
            WHERE created_by = %s
              AND lifecycle_state = 'PROPOSED'
        """, (approved_by, approved_by, created_by))
        
        approved_counts["ratecodes"] = cursor.rowcount
        
        # Create history records
        create_approval_history(cursor, pipeline_run_id, created_by, approved_by)
        
        conn.commit()
        
        total_approved = sum(approved_counts.values())
        
        logger.info(
            f"Pipeline {pipeline_run_id}: Auto-approved {total_approved} records - "
            f"Vendors: {approved_counts['vendors']}, "
            f"Zones: {approved_counts['zones']}, "
            f"Ratecodes: {approved_counts['ratecodes']}"
        )
        
        cursor.close()
        conn.close()
        
        return {
            "pipelineRunId": pipeline_run_id,
            "approved": approved_counts,
            "total": total_approved,
            "approvedBy": approved_by,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error auto-approving records: {e}", exc_info=True)
        cursor.close()
        conn.close()
        raise


def create_approval_history(cursor, pipeline_run_id, created_by, approved_by):
    """Create history records for approved entities"""
    
    # Vendor history
    cursor.execute("""
        INSERT INTO mdm_vendor_history
        (vendor_id, vendor_name, lifecycle_state, match_confidence,
         source_system, created_by, approved_at, approved_by,
         change_type, change_reason)
        SELECT 
            vendor_id, vendor_name, 'ACTIVE', match_confidence,
            source_system, created_by, NOW(), %s,
            'AUTO_APPROVAL', %s
        FROM mdm_vendor
        WHERE created_by = %s
          AND lifecycle_state = 'ACTIVE'
          AND approved_by = %s
    """, (
        approved_by,
        f'Auto-approved via pipeline {pipeline_run_id}',
        created_by,
        approved_by
    ))
    
    # Zone history
    cursor.execute("""
        INSERT INTO mdm_zone_history
        (zone_id, zone_name, lifecycle_state, match_confidence,
         source_system, created_by, approved_at, approved_by,
         change_type, change_reason)
        SELECT 
            zone_id, zone_name, 'ACTIVE', match_confidence,
            source_system, created_by, NOW(), %s,
            'AUTO_APPROVAL', %s
        FROM mdm_zone
        WHERE created_by = %s
          AND lifecycle_state = 'ACTIVE'
          AND approved_by = %s
    """, (
        approved_by,
        f'Auto-approved via pipeline {pipeline_run_id}',
        created_by,
        approved_by
    ))
    
    # Ratecode history
    cursor.execute("""
        INSERT INTO mdm_ratecode_history
        (ratecode_id, rate_code_desc, lifecycle_state, match_confidence,
         source_system, created_by, approved_at, approved_by,
         change_type, change_reason)
        SELECT 
            ratecode_id, rate_code_desc, 'ACTIVE', match_confidence,
            source_system, created_by, NOW(), %s,
            'AUTO_APPROVAL', %s
        FROM mdm_ratecode
        WHERE created_by = %s
          AND lifecycle_state = 'ACTIVE'
          AND approved_by = %s
    """, (
        approved_by,
        f'Auto-approved via pipeline {pipeline_run_id}',
        created_by,
        approved_by
    ))