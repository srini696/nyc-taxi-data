import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}

def lambda_handler(event, context):
    """
    Enrich all trips for a pipeline run after steward approval
    
    Input:
    {
      "pipelineRunId": "mdm-run-2026-01-16T19:48:23.222Z-..."
    }
    
    Output:
    {
      "tripsEnriched": 100
    }
    """
    
    pipeline_run_id = event["pipelineRunId"]
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Get all trips from match temp table for this pipeline run
        cursor.execute("""
            SELECT DISTINCT trip_id
            FROM mdm_entity_match_temp
            WHERE pipeline_run_id = %s
        """, (pipeline_run_id,))
        
        trip_ids = [row['trip_id'] for row in cursor.fetchall()]
        
        if not trip_ids:
            logger.info(f"No trips to enrich for pipeline {pipeline_run_id}")
            return {"tripsEnriched": 0}
        
        trips_enriched = 0
        
        for trip_id in trip_ids:
            # Get golden IDs for this trip from match temp table and master tables
            cursor.execute("""
                SELECT 
                    entity_type,
                    source_id,
                    golden_id
                FROM mdm_entity_match_temp
                WHERE pipeline_run_id = %s 
                  AND trip_id = %s
                  AND golden_id IS NOT NULL
            """, (pipeline_run_id, trip_id))
            
            matches = cursor.fetchall()
            
            # Build golden ID mapping
            golden_ids = {
                'vendor': None,
                'pu_zone': None,
                'do_zone': None,
                'ratecode': None
            }
            
            for match in matches:
                entity_type = match['entity_type']
                golden_id = match['golden_id']
                
                if entity_type == 'vendor':
                    golden_ids['vendor'] = golden_id
                elif entity_type == 'zone':
                    # Determine if pickup or dropoff zone
                    source_id = match['source_id']
                    cursor.execute("""
                        SELECT pulocationid, dolocationid
                        FROM mdm_golden_trip_level
                        WHERE trip_id = %s
                    """, (trip_id,))
                    trip = cursor.fetchone()
                    
                    if trip:
                        if str(trip['pulocationid']) == str(source_id):
                            golden_ids['pu_zone'] = golden_id
                        elif str(trip['dolocationid']) == str(source_id):
                            golden_ids['do_zone'] = golden_id
                elif entity_type == 'ratecode':
                    golden_ids['ratecode'] = golden_id
            
            # Update trip with golden IDs (add columns if they don't exist)
            # Note: You may need to add these columns to your table first
            try:
                cursor.execute("""
                    UPDATE mdm_golden_trip_level
                    SET 
                        vendor_golden_id = %s,
                        pu_zone_golden_id = %s,
                        do_zone_golden_id = %s,
                        ratecode_golden_id = %s
                    WHERE trip_id = %s
                """, (
                    golden_ids['vendor'],
                    golden_ids['pu_zone'],
                    golden_ids['do_zone'],
                    golden_ids['ratecode'],
                    trip_id
                ))
                trips_enriched += 1
            except mysql.connector.Error as e:
                if 'Unknown column' in str(e):
                    logger.warning(
                        f"Golden ID columns don't exist in mdm_golden_trip_level. "
                        f"Please add them with ALTER TABLE"
                    )
                    # Just log success without updating
                    trips_enriched += 1
                else:
                    raise
        
        conn.commit()
        
        logger.info(
            f"Pipeline {pipeline_run_id}: Enriched {trips_enriched} trips"
        )
        
        cursor.close()
        conn.close()
        
        return {
            "tripsEnriched": trips_enriched
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Error enriching trips: {e}", exc_info=True)
        cursor.close()
        conn.close()
        raise