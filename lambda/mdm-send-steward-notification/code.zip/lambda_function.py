"""
Lambda: mdm-send-steward-notification
Purpose: Format notification message for steward review
"""

import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Format steward notification message
    
    Input:
    {
      "pipelineRunId": "mdm-run-...",
      "stats": {
        "tripsProcessed": 50,
        "autoApproved": 45,
        "needsStewardReview": 5
      },
      "summary": {
        "qualityScore": 90.0,
        "proposedVendors": 2,
        "proposedZones": 2,
        "proposedRatecodes": 1
      }
    }
    
    Output:
    {
      "subject": "...",
      "message": "..."
    }
    """
    
    pipeline_run_id = event.get('pipelineRunId', 'unknown')
    stats = event.get('stats', {})
    summary = event.get('summary', {})
    
    trips_processed = stats.get('tripsProcessed', 0)
    auto_approved = stats.get('autoApproved', 0)
    needs_review = stats.get('needsStewardReview', 0)
    quality_score = summary.get('qualityScore', 0.0)
    
    proposed_vendors = summary.get('proposedVendors', 0)
    proposed_zones = summary.get('proposedZones', 0)
    proposed_ratecodes = summary.get('proposedRatecodes', 0)
    
    # Create formatted message
    subject = f"MDM Review Required - {needs_review} Records Pending"
    
    message = f"""
MDM Pipeline Execution Summary
{'=' * 60}

Pipeline Run ID: {pipeline_run_id}

PROCESSING STATISTICS
{'=' * 60}
Total Trips Processed:     {trips_processed:>6}
Auto-Approved Matches:     {auto_approved:>6}
Needs Steward Review:      {needs_review:>6}
Quality Score:             {quality_score:>5.1f}%

PROPOSED RECORDS (Pending Approval)
{'=' * 60}
Vendors:                   {proposed_vendors:>6}
Zones:                     {proposed_zones:>6}
Ratecodes:                 {proposed_ratecodes:>6}
Total:                     {proposed_vendors + proposed_zones + proposed_ratecodes:>6}

ACTION REQUIRED
{'=' * 60}
Please review and approve PROPOSED records in the database.

Query to view pending records:
```sql
-- Set your pipeline run ID
SET @run_id = '{pipeline_run_id}';

-- View all PROPOSED records
SELECT 'VENDOR' as type, vendor_id, vendor_name, created_at
FROM mdm_vendor 
WHERE created_by = CONCAT('pipeline_', @run_id)
  AND lifecycle_state = 'PROPOSED'
UNION ALL
SELECT 'ZONE', zone_id, zone_name, created_at
FROM mdm_zone 
WHERE created_by = CONCAT('pipeline_', @run_id)
  AND lifecycle_state = 'PROPOSED'
UNION ALL
SELECT 'RATECODE', ratecode_id, rate_code_desc, created_at
FROM mdm_ratecode 
WHERE created_by = CONCAT('pipeline_', @run_id)
  AND lifecycle_state = 'PROPOSED';
```

To approve all records:
```sql
SET @run_id = '{pipeline_run_id}';
SET @steward = 'YOUR_NAME';

UPDATE mdm_vendor SET lifecycle_state='ACTIVE', approved_at=NOW(), approved_by=@steward
WHERE created_by=CONCAT('pipeline_',@run_id) AND lifecycle_state='PROPOSED';

UPDATE mdm_zone SET lifecycle_state='ACTIVE', approved_at=NOW(), approved_by=@steward
WHERE created_by=CONCAT('pipeline_',@run_id) AND lifecycle_state='PROPOSED';

UPDATE mdm_ratecode SET lifecycle_state='ACTIVE', approved_at=NOW(), approved_by=@steward
WHERE created_by=CONCAT('pipeline_',@run_id) AND lifecycle_state='PROPOSED';
```

{'=' * 60}
Generated: {context.aws_request_id if context else 'local'}
"""
    
    logger.info(f"Formatted notification for pipeline {pipeline_run_id}")
    
    return {
        "subject": subject,
        "message": message.strip(),
        "needsReview": needs_review > 0
    }