import mysql.connector
from rapidfuzz.distance import Levenshtein
import logging
import json
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SIM_AUTO_APPROVE = 92.0
SIM_DEDUP_MIN = 75.0

TABLE_CONFIG = {
    'vendor': {
        'table': 'mdm_vendor',
        'id': 'vendor_id',
        'source': 'source_vendor_id',
        'name': 'vendor_name'
    },
    'zone': {
        'table': 'mdm_zone',
        'id': 'zone_id',
        'source': 'source_zone_id',
        'name': 'zone_name'
    },
    'ratecode': {
        'table': 'mdm_ratecode',
        'id': 'ratecode_id',
        'source': 'source_ratecode_id',
        'name': 'rate_code_desc'
    }
}

def lambda_handler(event, context):
    pipeline_run_id = event.get('pipelineRunId')
    results = event.get('results', [])

    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        database='nyc_taxi_mdm',
        user='mdm_admin',
        password='Srinivas1998'
    )
    cursor = conn.cursor()

    summary = {
        'pipelineRunId': pipeline_run_id,
        'processedTrips': 0,
        'processedEntities': 0,
        'autoApproved': 0,
        'dedupQueued': 0
    }

    try:
        for trip in results:
            trip_id = trip['tripId']
            missing_entities = trip.get('missingEntities', [])
            summary['processedTrips'] += 1

            for ent in missing_entities:
                summary['processedEntities'] += 1

                entity_type = ent['entityType']
                source_id = ent['sourceId']
                proposed_name = ent.get('proposedName', f"{entity_type}_{source_id}")

                config = TABLE_CONFIG.get(entity_type)
                if not config:
                    continue

                # Fetch active golden records
                cursor.execute(
                    f"SELECT {config['id']}, {config['name']} "
                    f"FROM {config['table']} WHERE lifecycle_state='ACTIVE'"
                )
                records = cursor.fetchall()

                best_match_id = None
                max_similarity = 0.0

                for rec_id, rec_name in records:
                    dist = Levenshtein.distance(
                        proposed_name.lower(), rec_name.lower()
                    )
                    max_len = max(len(proposed_name), len(rec_name))
                    similarity = 100 * (1 - dist / max_len) if max_len else 0

                    if similarity > max_similarity:
                        max_similarity = similarity
                        best_match_id = rec_id

                lifecycle_state = 'PROPOSED'
                auto_approved = False
                dedup_queued = False

                if max_similarity >= SIM_AUTO_APPROVE:
                    lifecycle_state = 'ACTIVE'
                    auto_approved = True
                    summary['autoApproved'] += 1
                elif max_similarity >= SIM_DEDUP_MIN:
                    dedup_queued = True
                    summary['dedupQueued'] += 1

                # Store TEMP result
                cursor.execute("""
                    INSERT INTO mdm_entity_match_temp (
                        pipeline_run_id, trip_id, entity_type,
                        source_id, proposed_name,
                        golden_id, match_confidence,
                        lifecycle_state, auto_approved, dedup_queued
                    ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """, (
                    pipeline_run_id, trip_id, entity_type,
                    source_id, proposed_name,
                    best_match_id, round(max_similarity, 2),
                    lifecycle_state, auto_approved, dedup_queued
                ))

        conn.commit()

    except Exception as e:
        logger.error(f"Batch processing failed: {e}")
        conn.rollback()
        raise

    finally:
        cursor.close()
        conn.close()

    # ✅ VERY SMALL output for Step Functions
    return {
        'pipelineRunId': pipeline_run_id,
        'processedTrips': summary['processedTrips'],
        'processedEntities': summary['processedEntities'],
        'autoApproved': summary['autoApproved'],
        'dedupQueued': summary['dedupQueued'],
        'tempTable': 'mdm_entity_match_temp'
    }
