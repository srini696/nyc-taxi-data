import json
import mysql.connector

def lambda_handler(event, context):
    vendor_id = event['vendor_id']
    change_id = event['change_id']
    
    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        port=3306,
        user='mdm_admin',
        password='Srinivas1998',
        database='nyc_taxi_mdm'
    )
    cursor = conn.cursor()
    
    # Auto-approve
    cursor.execute("""
        UPDATE mdm_vendor 
        SET lifecycle_state = 'ACTIVE', approved_by = 'SYSTEM', approved_at = CURRENT_TIMESTAMP
        WHERE vendor_id = %s AND lifecycle_state = 'PROPOSED'
    """, (vendor_id,))
    
    # Log to history
    cursor.execute("""
        INSERT INTO mdm_vendor_history (change_id, vendor_id, lifecycle_state, 
                                       created_by, approved_by, change_type, change_reason)
        SELECT %s, vendor_id, 'ACTIVE', created_by, 'SYSTEM', 'UPDATE', 
               'Auto-approved (high confidence)'
        FROM mdm_vendor WHERE vendor_id = %s
    """, (change_id + 1, vendor_id))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return {'statusCode': 200, 'approved': True}
