"""
MDM Check Proposed Records Lambda
Checks if there are any PROPOSED records awaiting steward approval
"""

import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}


def lambda_handler(event, context):
    """
    Check for PROPOSED records that need steward approval
    Returns counts and boolean indicating if any exist
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    
    logger.info(f"Checking for proposed records in pipeline {pipeline_run_id}")
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Count PROPOSED vendors
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM mdm_vendor 
            WHERE lifecycle_state = 'PROPOSED'
        """)
        vendor_count = cursor.fetchone()['count']
        
        # Count PROPOSED zones
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM mdm_zone 
            WHERE lifecycle_state = 'PROPOSED'
        """)
        zone_count = cursor.fetchone()['count']
        
        # Count PROPOSED ratecodes
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM mdm_ratecode 
            WHERE lifecycle_state = 'PROPOSED'
        """)
        ratecode_count = cursor.fetchone()['count']
        
        total_proposed = vendor_count + zone_count + ratecode_count
        has_proposed = total_proposed > 0
        
        logger.info(
            f"Found {total_proposed} proposed records: "
            f"{vendor_count} vendors, {zone_count} zones, {ratecode_count} ratecodes"
        )
        
        return {
            "hasProposed": has_proposed,
            "totalProposed": total_proposed,
            "counts": {
                "vendors": vendor_count,
                "zones": zone_count,
                "ratecodes": ratecode_count
            }
        }
        
    except Exception as e:
        logger.error(f"Error checking proposed records: {e}", exc_info=True)
        return {
            "hasProposed": False,
            "totalProposed": 0,
            "counts": {
                "vendors": 0,
                "zones": 0,
                "ratecodes": 0
            },
            "error": str(e)
        }
        
    finally:
        cursor.close()
        conn.close()