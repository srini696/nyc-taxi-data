import json
import mysql.connector
from fuzzywuzzy import fuzz
import boto3

def lambda_handler(event, context):
    # Parse input
    vendor_name = event['vendor_name']
    source_system = event['source_system']
    user_role = event.get('user_role', 'unknown')
    
    # Connect to RDS
    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        port=3306,
        user='mdm_admin',
        password='Srinivas1998',
        database='nyc_taxi_mdm'
    )
    cursor = conn.cursor()
    
    # Fuzzy match against ACTIVE vendors
    cursor.execute("SELECT vendor_id, vendor_name FROM mdm_vendor WHERE lifecycle_state = 'ACTIVE'")
    active_vendors = cursor.fetchall()
    
    max_score = 0
    best_match_id = None
    for vendor_id, vendor_name_db in active_vendors:
        score = fuzz.token_set_ratio(vendor_name.lower(), vendor_name_db.lower())
        if score > max_score:
            max_score = score
            best_match_id = vendor_id
    
    # Insert PROPOSED vendor
    cursor.execute("""
        INSERT INTO mdm_vendor (source_vendor_id, vendor_name, lifecycle_state, 
                               match_confidence, source_system, created_by)
        VALUES (%s, %s, 'PROPOSED', %s, %s, %s)
    """, (None, vendor_name, max_score, source_system, user_role))
    
    vendor_id = cursor.lastrowid
    change_id = vendor_id * 1000 + 1  # Simple CDC ID
    
    # Log to history
    cursor.execute("""
        INSERT INTO mdm_vendor_history (change_id, vendor_id, vendor_name, lifecycle_state,
                                       match_confidence, source_system, created_by, change_type, change_reason)
        VALUES (%s, %s, %s, 'PROPOSED', %s, %s, %s, 'INSERT', 'Initial proposal')
    """, (change_id, vendor_id, vendor_name, max_score, source_system, user_role))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return {
    'vendor_id': vendor_id,
    'match_confidence': max_score,
    'best_match_id': best_match_id,
    'change_id': change_id
    }
