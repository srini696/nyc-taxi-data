"""
MDM Process Pipeline Lambda
Fetches trips from curated layer, matches entities using fuzzy logic,
creates PROPOSED records for steward approval.
Does NOT enrich trips - enrichment happens after approval.
"""

import mysql.connector
from mysql.connector import pooling
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998",
    "autocommit": False
}

connection_pool = None


def get_connection_pool():
    """Get or create database connection pool"""
    global connection_pool
    if connection_pool is None:
        connection_pool = pooling.MySQLConnectionPool(
            pool_name="mdm_process_pool",
            pool_size=5,
            pool_reset_session=True,
            **DB_CONFIG
        )
    return connection_pool


def levenshtein_distance(s1, s2):
    """Calculate Levenshtein distance between two strings"""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]


def similarity_score(s1, s2):
    """Calculate similarity score (0.0 to 1.0) between two strings"""
    if not s1 or not s2:
        return 0.0
    
    s1_lower = s1.lower().strip()
    s2_lower = s2.lower().strip()
    
    distance = levenshtein_distance(s1_lower, s2_lower)
    max_len = max(len(s1_lower), len(s2_lower))
    
    return 1.0 - (distance / max_len) if max_len > 0 else 1.0


def fuzzy_match(proposed_name, active_entities, name_field):
    """
    Fuzzy match a proposed name against active entities
    Returns: (best_match, best_score) or (None, best_score)
    """
    if not proposed_name or not active_entities:
        return None, 0.0
    
    best_match = None
    best_score = 0.0
    
    for entity in active_entities:
        entity_name = entity.get(name_field, '')
        if not entity_name:
            continue
        
        score = similarity_score(proposed_name, entity_name)
        if score > best_score:
            best_score = score
            best_match = entity
    
    return (best_match, best_score) if best_score >= 0.85 else (None, best_score)


def ensure_tracking_table(cursor):
    """Ensure mdm_process_tracker table exists"""
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mdm_process_tracker (
                trip_id BIGINT PRIMARY KEY,
                pipeline_run_id VARCHAR(100),
                source_layer VARCHAR(50) DEFAULT 'curated_trip_level',
                match_status VARCHAR(30),
                needs_approval BOOLEAN DEFAULT FALSE,
                is_enriched BOOLEAN DEFAULT FALSE,
                processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_match_status (match_status),
                INDEX idx_needs_approval (needs_approval),
                INDEX idx_is_enriched (is_enriched),
                INDEX idx_pipeline (pipeline_run_id)
            )
        """)
        logger.info("Tracking table verified/created")
    except Exception as e:
        logger.warning(f"Error creating tracking table: {e}")


def lambda_handler(event, context):
    """
    Main handler: Fetch trips, match entities, create PROPOSED records
    """
    
    pipeline_run_id = event.get('pipelineRunId', f'mdm-run-{datetime.now().isoformat()}')
    batch_size = event.get('batchSize', 100000)
    auto_approve_threshold = event.get('autoApproveThreshold', 0.85)
    
    logger.info(f"Starting batch processing for pipeline {pipeline_run_id}")
    logger.info(f"Batch size: {batch_size}, Auto-approve threshold: {auto_approve_threshold}")
    
    pool = get_connection_pool()
    conn = pool.get_connection()
    cursor = conn.cursor(dictionary=True)
    
    stats = {
        "tripsProcessed": 0,
        "autoApproved": 0,
        "needsStewardReview": 0
    }
    
    try:
        # Ensure tracking table exists (with autocommit for DDL)
        conn.autocommit = True
        ensure_tracking_table(cursor)
        conn.autocommit = False
        
        # ================================================================
        # PHASE 1: FETCH UNPROCESSED TRIPS FROM CURATED LAYER
        # ================================================================
        logger.info("Fetching unprocessed trips from curated layer...")
        
        cursor.execute("""
            SELECT 
                t.trip_id, 
                t.vendorid, 
                t.vendor_name,
                t.pulocationid, 
                t.pu_zone,
                t.dolocationid, 
                t.do_zone,
                t.ratecodeid, 
                t.rate_code_desc
            FROM mdm_golden_trip_level t
            WHERE t.data_zone = 'curated_trip_level'
              AND NOT EXISTS (
                  SELECT 1 FROM mdm_process_tracker pt
                  WHERE pt.trip_id = t.trip_id
                    AND pt.source_layer = 'curated_trip_level'
              )
            ORDER BY t.trip_id
            LIMIT %s
        """, (batch_size,))
        
        trips = cursor.fetchall()
        stats["tripsProcessed"] = len(trips)
        
        if not trips:
            logger.info("No unprocessed trips found")
            return {
                "pipelineRunId": pipeline_run_id,
                "status": "NO_DATA",
                "stats": stats,
                "summary": {
                    "proposedVendors": 0,
                    "proposedZones": 0,
                    "proposedRatecodes": 0,
                    "qualityScore": 100.0
                }
            }
        
        trip_ids = [t['trip_id'] for t in trips]
        logger.info(f"Fetched {len(trips)} unprocessed trips")
        
        # ================================================================
        # PHASE 2: LOAD ACTIVE MASTER DATA
        # ================================================================
        logger.info("Loading active master data...")
        
        cursor.execute("""
            SELECT source_vendor_id, vendor_id, vendor_name 
            FROM mdm_vendor WHERE lifecycle_state='ACTIVE'
        """)
        active_vendors = {r["source_vendor_id"]: r for r in cursor.fetchall()}
        
        cursor.execute("""
            SELECT source_zone_id, zone_id, zone_name 
            FROM mdm_zone WHERE lifecycle_state='ACTIVE'
        """)
        active_zones = {r["source_zone_id"]: r for r in cursor.fetchall()}
        
        cursor.execute("""
            SELECT source_ratecode_id, ratecode_id, rate_code_desc 
            FROM mdm_ratecode WHERE lifecycle_state='ACTIVE'
        """)
        active_ratecodes = {r["source_ratecode_id"]: r for r in cursor.fetchall()}
        
        logger.info(f"Loaded {len(active_vendors)} vendors, {len(active_zones)} zones, {len(active_ratecodes)} ratecodes")
        
        # ================================================================
        # PHASE 3: MATCH ENTITIES AND COLLECT PROPOSED RECORDS
        # ================================================================
        logger.info("Matching entities with fuzzy logic...")
        
        proposed_vendors = {}
        proposed_zones = {}
        proposed_ratecodes = {}
        
        auto_approved_count = 0
        needs_review_count = 0
        
        for trip in trips:
            trip_needs_review = False
            
            # --- VENDOR MATCHING ---
            vid = trip["vendorid"]
            if vid and vid not in active_vendors:
                matched, confidence = fuzzy_match(
                    trip["vendor_name"], 
                    list(active_vendors.values()), 
                    'vendor_name'
                )
                
                if matched and confidence >= auto_approve_threshold:
                    auto_approved_count += 1
                    logger.debug(f"Vendor {vid} auto-approved (matched {matched['vendor_name']} with {confidence:.2f})")
                else:
                    proposed_vendors[vid] = trip["vendor_name"] or f'Vendor_{vid}'
                    trip_needs_review = True
                    logger.debug(f"Vendor {vid} needs review (best score: {confidence:.2f})")
            
            # --- PICKUP ZONE MATCHING ---
            pu = trip["pulocationid"]
            if pu and pu not in active_zones:
                matched, confidence = fuzzy_match(
                    trip["pu_zone"],
                    list(active_zones.values()),
                    'zone_name'
                )
                
                if matched and confidence >= auto_approve_threshold:
                    auto_approved_count += 1
                    logger.debug(f"PU Zone {pu} auto-approved (matched {matched['zone_name']} with {confidence:.2f})")
                else:
                    proposed_zones[pu] = trip["pu_zone"] or f'Zone_{pu}'
                    trip_needs_review = True
                    logger.debug(f"PU Zone {pu} needs review (best score: {confidence:.2f})")
            
            # --- DROPOFF ZONE MATCHING ---
            do = trip["dolocationid"]
            if do and do not in active_zones and do not in proposed_zones:
                matched, confidence = fuzzy_match(
                    trip["do_zone"],
                    list(active_zones.values()),
                    'zone_name'
                )
                
                if matched and confidence >= auto_approve_threshold:
                    auto_approved_count += 1
                    logger.debug(f"DO Zone {do} auto-approved (matched {matched['zone_name']} with {confidence:.2f})")
                else:
                    proposed_zones[do] = trip["do_zone"] or f'Zone_{do}'
                    trip_needs_review = True
                    logger.debug(f"DO Zone {do} needs review (best score: {confidence:.2f})")
            
            # --- RATECODE MATCHING ---
            rc = trip["ratecodeid"]
            if rc and rc not in active_ratecodes:
                matched, confidence = fuzzy_match(
                    trip["rate_code_desc"],
                    list(active_ratecodes.values()),
                    'rate_code_desc'
                )
                
                if matched and confidence >= auto_approve_threshold:
                    auto_approved_count += 1
                    logger.debug(f"Ratecode {rc} auto-approved (matched {matched['rate_code_desc']} with {confidence:.2f})")
                else:
                    proposed_ratecodes[rc] = trip["rate_code_desc"] or f'Ratecode_{rc}'
                    trip_needs_review = True
                    logger.debug(f"Ratecode {rc} needs review (best score: {confidence:.2f})")
            
            if trip_needs_review:
                needs_review_count += 1
        
        stats["autoApproved"] = auto_approved_count
        stats["needsStewardReview"] = needs_review_count
        
        logger.info(f"Matching complete: {auto_approved_count} auto-approved, {needs_review_count} need review")
        
        # ================================================================
        # PHASE 4: INSERT PROPOSED RECORDS
        # ================================================================
        logger.info("Inserting proposed records...")
        
        if proposed_vendors:
            vendor_inserts = [
                (vid, name, 'nyc_taxi_curated', f'pipeline_{pipeline_run_id}') 
                for vid, name in proposed_vendors.items()
            ]
            cursor.executemany("""
                INSERT IGNORE INTO mdm_vendor 
                (source_vendor_id, vendor_name, lifecycle_state, source_system, created_by)
                VALUES (%s, %s, 'PROPOSED', %s, %s)
            """, vendor_inserts)
            logger.info(f"Inserted {len(proposed_vendors)} proposed vendors")
        
        if proposed_zones:
            zone_inserts = [
                (zid, name, 'nyc_taxi_curated', f'pipeline_{pipeline_run_id}') 
                for zid, name in proposed_zones.items()
            ]
            cursor.executemany("""
                INSERT IGNORE INTO mdm_zone 
                (source_zone_id, zone_name, lifecycle_state, source_system, created_by)
                VALUES (%s, %s, 'PROPOSED', %s, %s)
            """, zone_inserts)
            logger.info(f"Inserted {len(proposed_zones)} proposed zones")
        
        if proposed_ratecodes:
            ratecode_inserts = [
                (rid, desc, 'nyc_taxi_curated', f'pipeline_{pipeline_run_id}') 
                for rid, desc in proposed_ratecodes.items()
            ]
            cursor.executemany("""
                INSERT IGNORE INTO mdm_ratecode 
                (source_ratecode_id, rate_code_desc, lifecycle_state, source_system, created_by)
                VALUES (%s, %s, 'PROPOSED', %s, %s)
            """, ratecode_inserts)
            logger.info(f"Inserted {len(proposed_ratecodes)} proposed ratecodes")
        
        # ================================================================
        # PHASE 5: TRACK PROCESSED TRIPS
        # ================================================================
        logger.info("Tracking processed trips...")
        
        if trip_ids:
            # Determine match status for this batch
            has_any_proposed = bool(proposed_vendors or proposed_zones or proposed_ratecodes)
            match_status = 'PENDING_APPROVAL' if has_any_proposed else 'AUTO_APPROVED'
            
            tracker_inserts = [
                (tid, pipeline_run_id, 'curated_trip_level', match_status, has_any_proposed, False) 
                for tid in trip_ids
            ]
            
            cursor.executemany("""
                INSERT INTO mdm_process_tracker 
                (trip_id, pipeline_run_id, source_layer, match_status, needs_approval, is_enriched, processed_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
                ON DUPLICATE KEY UPDATE 
                    pipeline_run_id = VALUES(pipeline_run_id),
                    match_status = VALUES(match_status),
                    needs_approval = VALUES(needs_approval),
                    processed_at = NOW()
            """, tracker_inserts)
            
            logger.info(f"Tracked {len(trip_ids)} trips with status: {match_status}")
        
        conn.commit()
        
        # Calculate quality score
        total_matches = auto_approved_count + needs_review_count
        quality_score = (auto_approved_count / total_matches * 100) if total_matches > 0 else 100.0
        
        logger.info(
            f"Batch completed - Trips: {stats['tripsProcessed']}, "
            f"Auto-approved: {stats['autoApproved']}, Needs review: {stats['needsStewardReview']}, "
            f"Quality: {quality_score:.2f}%"
        )
        
        return {
            "pipelineRunId": pipeline_run_id,
            "status": "SUCCESS",
            "stats": stats,
            "summary": {
                "proposedVendors": len(proposed_vendors),
                "proposedZones": len(proposed_zones),
                "proposedRatecodes": len(proposed_ratecodes),
                "qualityScore": quality_score
            }
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Batch processing failed: {e}", exc_info=True)
        return {
            "pipelineRunId": pipeline_run_id,
            "status": "FAILED",
            "error": str(e),
            "stats": stats
        }
        
    finally:
        cursor.close()
        conn.close()