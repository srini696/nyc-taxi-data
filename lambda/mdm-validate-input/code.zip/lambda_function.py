import json
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
   
    
    input_data = event.get('input', event)
    pipeline_run_id = input_data.get('pipelineRunId', f"run-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
    
    # Data quality checks matching your DDL schema
    dq_checks = {
        'trip_id_present': bool(input_data.get('tripData', {}).get('tripId')),
        'vendorid_valid': input_data.get('tripData', {}).get('vendorid') in [1,2,6,7,None],
        'ratecodeid_valid': input_data.get('tripData', {}).get('ratecodeid') in [1,2,3,4,5,6,99,None],
        'location_ids_positive': all(x > 0 for x in [
            input_data.get('tripData', {}).get('pulocationid'),
            input_data.get('tripData', {}).get('dolocationid')
        ] if x),
        'amounts_positive': all(x >= 0 for x in [
            input_data.get('tripData', {}).get('fare_amount'),
            input_data.get('tripData', {}).get('total_amount')
        ] if x)
    }
    
    passed = sum(1 for v in dq_checks.values() if v)
    quality_score = (passed / len(dq_checks)) * 100
    
    result = {
        'pipelineRunId': pipeline_run_id,
        'dataQualityScore': quality_score,
        'qualityPassed': quality_score >= 90,
        'failedChecks': {k: v for k, v in dq_checks.items() if not v},
        'triggeredBy': input_data.get('triggeredBy', 'unknown'),
        'tripData': input_data.get('tripData', {})
    }
    
    logger.info(f"Validation: {quality_score:.1f}% passed={result['qualityPassed']}")
    return result
