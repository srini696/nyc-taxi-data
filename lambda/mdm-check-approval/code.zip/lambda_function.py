"""
MDM Check Approvals Lambda
Detects when steward has approved PROPOSED records (changed to ACTIVE)
"""

import mysql.connector
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998"
}


def lambda_handler(event, context):
    """
    Check for records that were recently approved by steward
    (PROPOSED -> ACTIVE with recent approved_at timestamp)
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    
    logger.info(f"Checking for approved records in pipeline {pipeline_run_id}")
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Find vendors approved in last 6 minutes (just after the wait period)
        cursor.execute("""
            SELECT 
                'VENDOR' as entity_type,
                vendor_id as golden_id,
                source_vendor_id as source_id,
                vendor_name as name,
                approved_at,
                approved_by
            FROM mdm_vendor 
            WHERE lifecycle_state = 'ACTIVE'
              AND approved_at IS NOT NULL
              AND approved_at > DATE_SUB(NOW(), INTERVAL 6 MINUTE)
        """)
        approved_vendors = cursor.fetchall()
        
        # Find zones approved in last 6 minutes
        cursor.execute("""
            SELECT 
                'ZONE' as entity_type,
                zone_id as golden_id,
                source_zone_id as source_id,
                zone_name as name,
                approved_at,
                approved_by
            FROM mdm_zone 
            WHERE lifecycle_state = 'ACTIVE'
              AND approved_at IS NOT NULL
              AND approved_at > DATE_SUB(NOW(), INTERVAL 6 MINUTE)
        """)
        approved_zones = cursor.fetchall()
        
        # Find ratecodes approved in last 6 minutes
        cursor.execute("""
            SELECT 
                'RATECODE' as entity_type,
                ratecode_id as golden_id,
                source_ratecode_id as source_id,
                rate_code_desc as name,
                approved_at,
                approved_by
            FROM mdm_ratecode 
            WHERE lifecycle_state = 'ACTIVE'
              AND approved_at IS NOT NULL
              AND approved_at > DATE_SUB(NOW(), INTERVAL 6 MINUTE)
        """)
        approved_ratecodes = cursor.fetchall()
        
        # Combine all approved records
        all_approved = approved_vendors + approved_zones + approved_ratecodes
        
        # Check if there are still any PROPOSED records
        cursor.execute("""
            SELECT 
                (SELECT COUNT(*) FROM mdm_vendor WHERE lifecycle_state = 'PROPOSED') +
                (SELECT COUNT(*) FROM mdm_zone WHERE lifecycle_state = 'PROPOSED') +
                (SELECT COUNT(*) FROM mdm_ratecode WHERE lifecycle_state = 'PROPOSED') as proposed_count
        """)
        proposed_count = cursor.fetchone()['proposed_count']
        
        has_new_approvals = len(all_approved) > 0
        all_proposed_processed = (proposed_count == 0)
        
        logger.info(
            f"Found {len(all_approved)} newly approved records: "
            f"{len(approved_vendors)} vendors, {len(approved_zones)} zones, {len(approved_ratecodes)} ratecodes"
        )
        logger.info(f"Remaining PROPOSED records: {proposed_count}")
        
        # Convert datetime objects to strings for JSON serialization
        for record in all_approved:
            if record.get('approved_at'):
                record['approved_at'] = record['approved_at'].isoformat()
        
        return {
            "hasNewApprovals": has_new_approvals,
            "allProposedProcessed": all_proposed_processed,
            "approvedRecords": all_approved,
            "stats": {
                "totalApproved": len(all_approved),
                "vendors": len(approved_vendors),
                "zones": len(approved_zones),
                "ratecodes": len(approved_ratecodes),
                "remainingProposed": proposed_count
            }
        }
        
    except Exception as e:
        logger.error(f"Error checking approvals: {e}", exc_info=True)
        return {
            "hasNewApprovals": False,
            "allProposedProcessed": False,
            "approvedRecords": [],
            "stats": {
                "totalApproved": 0,
                "vendors": 0,
                "zones": 0,
                "ratecodes": 0,
                "remainingProposed": 0
            },
            "error": str(e)
        }
        
    finally:
        cursor.close()
        conn.close()