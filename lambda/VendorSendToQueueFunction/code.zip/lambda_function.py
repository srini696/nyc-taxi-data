import json
import boto3
import mysql.connector

def lambda_handler(event, context):
    vendor_id = event['vendor_id']
    execution_arn = event['execution_arn']  # Step Functions ARN
    queue_url = 'https://sqs.us-east-1.amazonaws.com/473157801752/VendorReviewQueue'  # your queue
    
    # Get vendor details

    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        port=3306,
        user='mdm_admin',
        password='Srinivas1998',
        database='nyc_taxi_mdm'
    )

    cursor = conn.cursor()
    cursor.execute("SELECT vendor_name, match_confidence FROM mdm_vendor WHERE vendor_id = %s", (vendor_id,))
 
    name, confidence = cursor.fetchone()
    
    confidence_float = float(confidence) if confidence is not None else 0.0
    
    
    # Create message with serializable types only
    message = {
        'vendor_id': int(vendor_id),
        'vendor_name': str(name),
        'confidence': confidence_float,      
        'execution_arn': str(execution_arn), 
        'action_needed': 'REVIEW'
    }
    
    # Send to SQS
    sqs = boto3.client('sqs')
    sqs.send_message(QueueUrl=queue_url, MessageBody=json.dumps(message))
    
    return {
    "proposal": {
        "vendor_id": vendor_id
    },
    "statusCode": 200,
    "message": f"Sent vendor {vendor_id} to steward queue"
    }

