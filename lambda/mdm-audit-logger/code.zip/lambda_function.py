import mysql.connector
import json
import logging
import boto3
from datetime import datetime

def lambda_handler(event, context):
    """Log complete pipeline execution"""
    
    audit_record = {
        'pipeline_run_id': event.get('pipelineRunId'),
        'triggered_by': event.get('triggeredBy'),
         'entity_type': event.get('tripReferences', {}).get('Payload', {}).get('missingEntities', [{}])[0].get('entityType', 'UNKNOWN'),
        'records_processed': 1,
        'records_approved': 1 if event.get('goldenTrip') else 0,
        'quality_score': event.get('dataQualityScore'),
        'status': 'SUCCESS' if event.get('goldenTrip') else 'FAILED',
        'stepfn_execution': context.aws_request_id,
        'run_start': event.get('runStart'),
        'run_end': datetime.now().isoformat()
    }
    
    conn = mysql.connector.connect(
        host='nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com',
        database='nyc_taxi_mdm',
        user='mdm_admin',
        password='Srinivas1998'
    )
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO mdm_pipeline_audit (
            pipeline_run_id, triggered_by, entity_type, records_processed,
            records_approved, quality_score, status, stepfn_execution, run_start, run_end
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, list(audit_record.values()))
    
    conn.commit()
    cursor.close()
    conn.close()
    
    return {'auditLogged': True}
