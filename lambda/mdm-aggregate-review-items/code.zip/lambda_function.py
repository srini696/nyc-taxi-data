"""
Update deduplication queues for newly approved records
Compares new ACTIVE records with existing ACTIVE records
"""

import mysql.connector
from mysql.connector import pooling
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_CONFIG = {
    "host": "nyc-taxi-mdm-db.cg9gsgsi831x.us-east-1.rds.amazonaws.com",
    "database": "nyc_taxi_mdm",
    "user": "mdm_admin",
    "password": "Srinivas1998",
    "autocommit": False
}

connection_pool = None

def get_connection_pool():
    global connection_pool
    if connection_pool is None:
        connection_pool = pooling.MySQLConnectionPool(
            pool_name="mdm_dedup_pool",
            pool_size=5,
            pool_reset_session=True,
            **DB_CONFIG
        )
    return connection_pool


def levenshtein_distance(s1, s2):
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]


def similarity_score(s1, s2):
    if not s1 or not s2:
        return 0.0
    
    s1_lower = s1.lower().strip()
    s2_lower = s2.lower().strip()
    
    distance = levenshtein_distance(s1_lower, s2_lower)
    max_len = max(len(s1_lower), len(s2_lower))
    
    return 1.0 - (distance / max_len) if max_len > 0 else 1.0


def lambda_handler(event, context):
    """
    Compare newly approved records with existing ACTIVE records
    Add potential duplicates to dedup queues
    """
    
    pipeline_run_id = event.get('pipelineRunId')
    approved_records = event.get('approvedRecords', {})
    
    pool = get_connection_pool()
    conn = pool.get_connection()
    cursor = conn.cursor(dictionary=True)
    
    stats = {
        "vendorPairs": 0,
        "zonePairs": 0,
        "ratecodePairs": 0
    }
    
    try:
        # Process Vendors
        approved_vendors = approved_records.get('vendors', [])
        if approved_vendors:
            cursor.execute("""
                SELECT vendor_id, vendor_name 
                FROM mdm_vendor 
                WHERE lifecycle_state = 'ACTIVE'
            """)
            all_vendors = cursor.fetchall()
            
            for new_vendor in approved_vendors:
                new_id = new_vendor['vendor_id']
                new_name = new_vendor['vendor_name']
                
                for existing_vendor in all_vendors:
                    if existing_vendor['vendor_id'] == new_id:
                        continue
                    
                    score = similarity_score(new_name, existing_vendor['vendor_name'])
                    
                    if 0.70 <= score < 0.95:  # Potential duplicate range
                        confidence = 'HIGH' if score >= 0.85 else 'MEDIUM' if score >= 0.75 else 'LOW'
                        
                        cursor.execute("""
                            INSERT IGNORE INTO mdm_vendor_dedup_queue
                            (vendor_id_1, vendor_id_2, match_score, confidence_level)
                            VALUES (%s, %s, %s, %s)
                        """, (new_id, existing_vendor['vendor_id'], score, confidence))
                        stats["vendorPairs"] += cursor.rowcount
        
        # Process Zones
        approved_zones = approved_records.get('zones', [])
        if approved_zones:
            cursor.execute("""
                SELECT zone_id, zone_name 
                FROM mdm_zone 
                WHERE lifecycle_state = 'ACTIVE'
            """)
            all_zones = cursor.fetchall()
            
            for new_zone in approved_zones:
                new_id = new_zone['zone_id']
                new_name = new_zone['zone_name']
                
                for existing_zone in all_zones:
                    if existing_zone['zone_id'] == new_id:
                        continue
                    
                    score = similarity_score(new_name, existing_zone['zone_name'])
                    
                    if 0.70 <= score < 0.95:
                        confidence = 'HIGH' if score >= 0.85 else 'MEDIUM' if score >= 0.75 else 'LOW'
                        
                        cursor.execute("""
                            INSERT IGNORE INTO mdm_zone_dedup_queue
                            (zone_id_1, zone_id_2, match_score, confidence_level)
                            VALUES (%s, %s, %s, %s)
                        """, (new_id, existing_zone['zone_id'], score, confidence))
                        stats["zonePairs"] += cursor.rowcount
        
        # Process Ratecodes
        approved_ratecodes = approved_records.get('ratecodes', [])
        if approved_ratecodes:
            cursor.execute("""
                SELECT ratecode_id, rate_code_desc 
                FROM mdm_ratecode 
                WHERE lifecycle_state = 'ACTIVE'
            """)
            all_ratecodes = cursor.fetchall()
            
            for new_ratecode in approved_ratecodes:
                new_id = new_ratecode['ratecode_id']
                new_desc = new_ratecode['rate_code_desc']
                
                for existing_ratecode in all_ratecodes:
                    if existing_ratecode['ratecode_id'] == new_id:
                        continue
                    
                    score = similarity_score(new_desc, existing_ratecode['rate_code_desc'])
                    
                    if 0.70 <= score < 0.95:
                        confidence = 'HIGH' if score >= 0.85 else 'MEDIUM' if score >= 0.75 else 'LOW'
                        
                        cursor.execute("""
                            INSERT IGNORE INTO mdm_ratecode_dedup_queue
                            (ratecode_id_1, ratecode_id_2, match_score, confidence_level)
                            VALUES (%s, %s, %s, %s)
                        """, (new_id, existing_ratecode['ratecode_id'], score, confidence))
                        stats["ratecodePairs"] += cursor.rowcount
        
        conn.commit()
        
        logger.info(
            f"Dedup queues updated: Vendors={stats['vendorPairs']}, "
            f"Zones={stats['zonePairs']}, Ratecodes={stats['ratecodePairs']}"
        )
        
        return {
            "pipelineRunId": pipeline_run_id,
            "stats": stats
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Dedup queue update failed: {e}", exc_info=True)
        raise
        
    finally:
        cursor.close()
        conn.close()